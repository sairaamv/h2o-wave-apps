H2O Wave SDK
Realtime web apps and dashboards for Python.

Get started: https://h2oai.github.io/wave/


